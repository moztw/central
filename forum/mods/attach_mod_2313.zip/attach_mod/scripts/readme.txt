Within this directory you will find all old update and install/uninstall scripts if you feel the need to
use them, as well as additional scripts.
All scripts here have to be copied to the phpBB2 Root Directory (if the Instructions says to run the file) 
and don't forget to delete them after execution.

Additional Scripts:

attach_update_224_to_latest.php/tpl:
This script is responsible for udating older 2.2.x versions to the latest version. Copy attach_update_224_to_latest.php
and attach_update_224_to_latest.tpl to your phpBB2 root folder and run the attach_update_224_to_latest.php file.
After the update went through, you might consider running the normal 2.3.x update process too.

mod_table_uninst.php:
This script unsinstalls the Attachment Mod tables.

update_to_221.php:
This script updates any older versions prior to 2.2.0 to version 2.2.1. After this has been done, you are able to update
to the latest version using the 2.2.x updater.

create_thumbnails.php:
If you want to create thumbnails from already existing Attachments this is the file you need. :)
Before you use this script, please make sure you have visited the Special Category Screen
in your Administration Panel to search for the imagick program and to make sure you have
enabled Thumbnail Creation and tested the Settings.
After you have done so, Upload the script to your phpBB2 Directory and execute it.
You have to choose whether to create thumbnails manually (You can choose the Attachment) or
to create the Thumnails automatically, without any action required from you.
If you choose the manual way and the Attachment where you clicked on (Create Thumbnail Link) 
does not disappear from the list, the Thumnail Creation does not worked for this Attachment.

revar_filenames.php:
This file is for renaming your files within your Upload Directory to the Real Filename.
(for example translates 1_28732432523.zip to attach_mod.zip)
Please run this file only once after upgrading from 2.2.4.

check_lang_files.php:
This is mainly for Attachment Mod Language Pack Authors, to determine differences
between the English Attachment Mod Language Files and their files.
This file will list missing Language Variables and not anymore needed Language Variables.

