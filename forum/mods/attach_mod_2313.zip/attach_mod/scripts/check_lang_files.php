<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html;">
<meta http-equiv="Content-Style-Type" content="text/css">
<style type="text/css">
<!--

font,th,td,p,body { font-family: "Courier New", courier; font-size: 11pt }

a:link,a:active,a:visited { color : #006699; }
a:hover		{ text-decoration: underline; color : #DD6900;}

hr	{ height: 0px; border: solid #D1D7DC 0px; border-top-width: 1px;}

.maintitle,h1,h2	{font-weight: bold; font-size: 22px; font-family: "Trebuchet MS",Verdana, Arial, Helvetica, sans-serif; text-decoration: none; line-height : 120%; color : #000000;}

.ok {color:green}

/* Import the fancy styles for IE only (NS4.x doesn't use the @import function) */
@import url("templates/subSilver/formIE.css"); 
-->
</style>
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#006699" vlink="#5584AA">

<table width="100%" border="0" cellspacing="0" cellpadding="10" align="center"> 
	<tr>
		<td><table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td><img src="templates/subSilver/images/logo_phpBB.gif" border="0" alt="Forum Home" vspace="1" /></td>
				<td align="center" width="100%" valign="middle"><span class="maintitle">Checking Language Files</span></td>
			</tr>
		</table></td>
	</tr>
</table>

<br clear="all" />

<?php
// Compare the other Language Files with the English ones

// This script have to be in root
// $dirname = "./../root/language";
$dirname = './language';
$lang = array();

function format_text($in)
{
	$text = addslashes($in);
	$code_entities_match = array('#<#', '#>#', '#"#', '#:#', '#\[#', '#\]#', '#\(#', '#\)#', '#\{#', '#\}#');
	$code_entities_replace = array('&lt;', '&gt;', '&quot;', '&#58;', '&#91;', '&#93;', '&#40;', '&#41;', '&#123;', '&#125;');
	$text = preg_replace($code_entities_match, $code_entities_replace, $text);
	$text = str_replace("  ", "&nbsp; ", $text);
	// now Replace 2 spaces with " &nbsp;" to catch odd #s of spaces.
	$text = str_replace("  ", " &nbsp;", $text);
	// Replace tabs with "&nbsp; &nbsp;" so tabbed code indents sorta right without making huge long lines.
	$text = str_replace("\t", "&nbsp; &nbsp;", $text);
	return nl2br($text);
}


function compare_files($source_lang, $dest_lang, $file_var)
{
	global $dirname, $lang;

	$lang = array();

	print_r("Checking <b>" . $file_var . "</b> Lang File <br />");
	print_r("Source Language: <b>" . $source_lang . "</b><br />");

	include($dirname . '/' . $source_lang . '/lang_' . $file_var . '_attach.php');

	$lang_entry_src = array();
	$num_entries_src = 0;
	@reset($lang);
	while( list($key, $value) = each($lang) )
	{
		$lang_entry_src['key'][$num_entries_src] = $key;
		$lang_entry_src['value'][$num_entries_src] = $value;
		$num_entries_src++;
	}

	$lang = array();

	print_r("Destination Language: <b>" . $dest_lang . "</b><br />");

	include($dirname . '/' . $dest_lang . '/lang_' . $file_var . '_attach.php');

	$lang_entry_dst = array();
	$num_entries_dst = 0;
	@reset($lang);
	while( list($key, $value) = each($lang) )
	{
		$lang_entry_dst['key'][$num_entries_dst] = $key;
		$lang_entry_dst['value'][$num_entries_dst] = $value;
		$num_entries_dst++;
	}

	$missing = array();

	// Missing Language Variables
	for ($i = 0; $i < $num_entries_src; $i++)
	{
		if (!in_array($lang_entry_src['key'][$i], $lang_entry_dst['key']))
		{
			$missing['key'][] = $lang_entry_src['key'][$i];
			$missing['value'][] = $lang_entry_src['value'][$i];
		}
	}

	$not_needed = array();

	// Not anymore needed Lang Vars
	for ($i = 0; $i < $num_entries_dst; $i++)
	{
		if (!in_array($lang_entry_dst['key'][$i], $lang_entry_src['key']))
		{
			$not_needed['key'][] = $lang_entry_dst['key'][$i];
			$not_needed['value'][] = $lang_entry_dst['value'][$i];
		}
	}

/*
	$changed_content = array();

	for ($i = 0; $i < $num_entries_src; $i++)
	{
		for ($j = 0; $j < $num_entries_dst; $j++)
		{
			if (trim($lang_entry_dst['key'][$j]) == trim($lang_entry_src['key'][$i]))
			{
				if (trim($lang_entry_dst['value'][$j]) != trim($lang_entry_src['value'][$i]))
				{
					$changed_content['key'][] = $lang_entry_src['key'][$i];
					$changed_content['from'][] = $lang_entry_dst['value'][$j];
					$changed_content['to'][] = $lang_entry_src['value'][$i];
				}
			}
		}
	}
*/

	// Write down those Lang Vars
	print_r("<br />Missing Language Variables in " . $dest_lang . " " . $file_var . " Language File<br />");
	for ($i = 0; $i < count($missing['key']); $i++)
	{
		print_r("<br />\$lang['" . $missing['key'][$i] . "'] = '" . format_text($missing['value'][$i]) . "';");
	}

	print_r("<br /><br />These Language Variables are no longer needed within the " . $dest_lang . " " . $file_var . " Language File<br />");
	for ($i = 0; $i < count($not_needed['key']); $i++)
	{
		print_r("<br />\$lang['" . $not_needed['key'][$i] . "'] = '" . format_text($not_needed['value'][$i]) . "';");
	}
/*
	print_r("<br /><br />Language Variables changed in their content<br />");

	for ($i = 0; $i < count($changed_content['key']); $i++)
	{
		print_r("<br /><b>FROM:</b><br />\$lang['" . $changed_content['key'][$i] . "'] = '" . format_text($changed_content['from'][$i]) . "';<br /><b>TO:</b><br />\$lang['" . $changed_content['key'][$i] . "'] = '" . format_text($changed_content['to'][$i]) . "';<br />");
	}
*/
	print_r("<br /><br /><br />");
}


$dir = opendir($dirname);

while ( $file = readdir($dir) )
{
	if ( ereg("^lang_", $file) && !ereg("^lang_english", $file) && !is_file($dirname . '/' . $file) && !is_link($dirname . '/' . $file) )
	{
		compare_files('lang_english', $file, 'admin');
		compare_files('lang_english', $file, 'main');
	}
}

?>