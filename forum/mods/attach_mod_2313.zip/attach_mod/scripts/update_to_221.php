<?php
//
// update all versions of the Attachment Mod to Version 2.2.1 (2002-05-18)
//

//
// This File adds new variables to the Database
//

define('IN_PHPBB', true);
define('ATTACH_INSTALL', true);

$phpbb_root_path = './';
include($phpbb_root_path.'extension.inc');
include($phpbb_root_path.'common.'.$phpEx);	
include($phpbb_root_path.'includes/sql_parse.'.$phpEx);
	
/*
//
// Start session management
//
$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);
//
// End session management
//

if( !$userdata['session_logged_in'] )
{
	header("Location: " . append_sid("./login." . $phpEx));
}

if( $userdata['user_level'] != ADMIN )
{
	message_die(GENERAL_MESSAGE, $lang['Not_Authorised']);
}
*/

if ( (!isset($dbms)) || (($dbms != "mysql") && ($dbms != "mysql4") && ($dbms != "mssql") && ($dbms != "mssql-odbc") && ($dbms != "postgres")) )
{
	message_die(GENERAL_MESSAGE, "This Mod does only support MySQL, MSSQL and PostgreSQL.");
}
else if( isset($dbms) )
{
	include($phpbb_root_path.'includes/db.'.$phpEx);
}

$available_dbms = array(
	"mysql" => array(
		"SCHEMA" => "mysql", 
		"DELIM" => ";",
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_remarks"
	), 
	"mysql4" => array(
		"SCHEMA" => "mysql", 
		"DELIM" => ";", 
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_remarks"
	), 
	"postgres" => array(
		"SCHEMA" => "postgres", 
		"DELIM" => ";", 
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_comments"
	), 
	"mssql" => array(
		"SCHEMA" => "mssql", 
		"DELIM" => "GO", 
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_comments"
	),
	"mssql-odbc" =>	array(
		"SCHEMA" => "mssql", 
		"DELIM" => "GO",
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_comments"
	)
);

$remove_remarks = $available_dbms[$dbms]['COMMENTS'];;
$delimiter = $available_dbms[$dbms]['DELIM']; 
$delimiter_basic = $available_dbms[$dbms]['DELIM_BASIC']; 

$new_table = $table_prefix . 'attach';

$attach_config_table = $table_prefix . 'attach_config';
$attach_types_table = $table_prefix . 'attach_types';
$attach_desc_table = $table_prefix . 'attach_desc';

function query($sql, $errormsg)
{
	global $db;

	if ( !($result = $db->sql_query($sql)) )
	{
		print "<br><font color=\"red\">\n";
		print "$errormsg<br>";

		$sql_error = $db->sql_error();
		print $sql_error['code'] .": ". $sql_error['message']. "<br>\n";

		print "<pre>$sql</pre>";
		print "</font>\n";

		return FALSE;
	}
	else
	{
		return $result;
	}
}

function insert_into_config($name, $value)
{
	global $db, $attach_config_table;

	$sql = "SELECT config_name FROM " . $attach_config_table . " WHERE config_name='" . $name . "'";

	$result = $db->sql_query($sql);

	if ($db->sql_numrows($result) != 0)
	{
		return;
	}

	echo 'Insert ' . $name . ' into ' . $attach_config_table . "...<br />";
	$sql = "INSERT INTO " . $attach_config_table . " (config_name, config_value) VALUES ('" . $name . "', '" . $value . "')";
	query($sql, "Couldn't insert " . $name . " into " . $attach_config_table . ".");
}

function delete_from_config($name)
{
	global $db, $attach_config_table;

	$sql = "SELECT config_name FROM " . $attach_config_table . " WHERE config_name='" . $name . "'";

	$result = $db->sql_query($sql);

	if ($db->sql_numrows($result) == 0)
	{
		return;
	}

	echo 'Delete ' . $name . ' from ' . $attach_config_table . "...<br />";
	$sql = "DELETE FROM " . $attach_config_table . " WHERE config_name = '" . $name . "'";
	query($sql, "Couldn't delete " . $name . " from " . $attach_config_table . ".");
}

function row_in_shema($table, $key)
{
	global $db;

	$sql = "SELECT " . $key . " FROM " . $table;

	$result = $db->sql_query($sql);

	if ($result)
	{
		return (TRUE);
	}
	else
	{
		return (FALSE);
	}
}

function evaluate_statement($sql_query)
{
	global $table_prefix, $remove_remarks, $delimiter, $db;
	
	$sql_query = preg_replace('/phpbb_/', $table_prefix, $sql_query);

	$sql_query = $remove_remarks($sql_query);
	$sql_query = split_sql_file($sql_query, $delimiter);

	$sql_count = count($sql_query);

	for($i = 0; $i < $sql_count; $i++)
	{
		echo "Running :: " . $sql_query[$i];
		flush();

		if ( !($result = $db->sql_query($sql_query[$i])) )
		{
			$errored = true;
			$error = $db->sql_error();
			echo " -> <b>FAILED</b> ---> <u>" . $error['message'] . "</u><br /><br />\n\n";
		}
		else
		{
			echo " -> <b>COMPLETED</b><br /><br />\n\n";
		}
	}
}

$attach_config = array();

$sql = "SELECT *
FROM " . $attach_config_table;

if(!$result = $db->sql_query($sql))
{
	message_die(GENERAL_ERROR, "Could not query attachment information", "", __LINE__, __FILE__, $sql);
}

while ($row = $db->sql_fetchrow($result))
{
	$attach_config[$row['config_name']] = trim($row['config_value']);
}

echo "<html>";
echo "<body>";

// Try to insert ALL config_values, if they don't exist
insert_into_config('upload_dir', 'files');
insert_into_config('max_filesize', '262144');
insert_into_config('upload_img','images/icon_clip.gif');
insert_into_config('max_attachments','3');
insert_into_config('disable_mod','0');
insert_into_config('topic_icon','');
insert_into_config('mime_table','');
insert_into_config('attachment_quota','52428800');
insert_into_config('allow_pm_attach', '1');
insert_into_config('max_attachments_pm','1');
insert_into_config('max_filesize_pm','262144');
insert_into_config('allow_ftp_upload','0');
insert_into_config('ftp_host','');
insert_into_config('ftp_path','');
insert_into_config('ftp_user','');
insert_into_config('ftp_pass','');
insert_into_config('download_path','');

delete_from_config('image_upload');

// Alter Table shema, if it is not altered already - update to v2.0.9
if (!row_in_shema($attach_desc_table, 'filesize'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") )
	{
		$sql_query = "ALTER TABLE phpbb_attach_desc ADD filesize int(20) NOT NULL;";
	}
	else if ( $dbms == "postgres" )
	{
		$sql_query = "ALTER TABLE phpbb_attach_desc ADD filesize int4 NOT NULL;";
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE [phpbb_attach_desc] WITH NOCHECK ADD
		[filesize] [int] NOT NULL ,
		GO";
	}

	evaluate_statement($sql_query);

	//
	// Collect all Attachments in Attachment Table
	//
	$sql = "SELECT attach_id, attach_filename FROM " . $attach_desc_table;

	$result = query($sql, "Couldn't select attachments");

	$attach_count = $db->sql_numrows($result);
	$attach_data = $db->sql_fetchrowset($result);

	for ($i = 0; $i < $attach_count; $i++)
	{
		$filesize = @filesize($attach_config['upload_dir'] . "/" . $attach_data[$i]['attach_filename']);

		echo "set filesize for " . $attach_data[$i]['attach_filename'] . " to " . $filesize . "...";
		query("UPDATE " . $attach_desc_table . " SET filesize = '" . $filesize . "' WHERE attach_id = " . $attach_data[$i]['attach_id'], "Couldn't insert filesize.");
		echo "done<br />";
	}
}

if (!row_in_shema($attach_desc_table, 'filetime'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") )
	{
		$sql_query = "ALTER TABLE phpbb_attach_desc ADD filetime int(11) DEFAULT '0' NOT NULL;";
	}
	else if ( $dbms == "postgres" )
	{
		$sql_query = "ALTER TABLE phpbb_attach_desc ADD filetime int4 DEFAULT '0' NOT NULL;";
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE [phpbb_attach_desc] WITH NOCHECK ADD
		[filetime] [int] NOT NULL ,
		CONSTRAINT [DF_phpbb_attach_desc_filetime] DEFAULT (0) FOR [filetime]
		GO";
	}
	evaluate_statement($sql_query);

	//
	// Collect all Attachments in Attachment Table
	//
	$sql = "SELECT attach_id, attach_filename FROM " . $attach_desc_table;

	$result = query($sql, "Couldn't select attachments");

	$attach_count = $db->sql_numrows($result);
	$attach_data = $db->sql_fetchrowset($result);

	for ($i = 0; $i < $attach_count; $i++)
	{
		$filetime = @filectime($attach_config['upload_dir'] . "/" . $attach_data[$i]['attach_filename']);

		echo "set filetime for " . $attach_data[$i]['attach_filename'] . " to " . $filetime . " (is " . create_date($board_config['default_dateformat'], $filetime, $board_config['board_timezone']) . ") ...";
		query("UPDATE " . $attach_desc_table . " SET filetime = '" . $filetime . "' WHERE attach_id = " . $attach_data[$i]['attach_id'], "Couldn't insert filetime.");
		echo "done<br />";
	}
}

// Alter Table shema, if it is not altered already - v2.1.0 to v2.1.1
if (!row_in_shema($attach_types_table, 'download_mode'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") )
	{
		$sql_query = "ALTER TABLE phpbb_attach_types ADD download_mode TINYINT(1) UNSIGNED DEFAULT '1' NOT NULL;";
	}
	else if ( $dbms == "postgres" )
	{
		$sql_query = "ALTER TABLE phpbb_attach_types ADD download_mode int2 DEFAULT '1' NOT NULL;";
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE [phpbb_attach_types] WITH NOCHECK ADD
		[download_mode] [tinyint] NOT NULL ,
		CONSTRAINT [DF_phpbb_attach_types_download_mode] DEFAULT (1) FOR [download_mode]
		GO";
	}
	evaluate_statement($sql_query);
}

if (!row_in_shema($attach_types_table, 'upload_image'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") )
	{
		$sql_query = "ALTER TABLE phpbb_attach_types ADD upload_image VARCHAR(100);";
	}
	else if ( $dbms == "postgres" )
	{
		$sql_query = "ALTER TABLE phpbb_attach_types ADD upload_image VARCHAR(100);";
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE [phpbb_attach_types] WITH NOCHECK ADD
        [upload_image] [varchar] (100) ,
		GO";
	}
	evaluate_statement($sql_query);
}

if (!row_in_shema($attach_types_table, 'max_filesize'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") )
	{
		$sql_query = "ALTER TABLE phpbb_attach_types ADD max_filesize INT(20) DEFAULT '0' NOT NULL;";
	}
	else if ( $dbms == "postgres" )
	{
		$sql_query = "ALTER TABLE phpbb_attach_types ADD max_filesize int4 DEFAULT '0' NOT NULL;";
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE [phpbb_attach_types] WITH NOCHECK ADD
        [max_filesize] [int] NOT NULL
		CONSTRAINT [DF_phpbb_attach_types_max_filesize] DEFAULT (0) FOR [max_filesize]
		GO";
	}
	evaluate_statement($sql_query);
}

if (!row_in_shema($attach_types_table, 'category'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") )
	{
		$sql_query = "ALTER TABLE phpbb_attach_types CHANGE is_image category TINYINT(2) DEFAULT '0' NOT NULL;";
	}
	else if ( $dbms == "postgres" )
	{
		$sql_query = "ALTER TABLE phpbb_attach_types RENAME is_image TO category; ALTER TABLE phpbb_attach_types ALTER category SET DEFAULT '0' NOT NULL;";
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE [phpbb_attach_types] WITH NOCHECK ADD
		[category] [tinyint] NOT NULL ,
		CONSTRAINT [DF_phpbb_attach_types_category] DEFAULT (0) FOR [category]
		GO";
	}
	evaluate_statement($sql_query);
}

// Alter Table shema, if it is not altered already - v2.1.1 to v2.2.1
if (!row_in_shema(FORUMS_TABLE, 'auth_download'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") )
	{
		$sql_query = "ALTER TABLE phpbb_forums ADD auth_download TINYINT(2) DEFAULT '0' NOT NULL;";
	}
	else if ( $dbms == "postgres" )
	{
		$sql_query = "ALTER TABLE phpbb_forums ADD auth_download int2 DEFAULT '0' NOT NULL;";
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE [phpbb_forums] WITH NOCHECK ADD 
		[auth_download] SMALLINT NOT NULL,	
		CONSTRAINT [DF_phpbb_forums_auth_download] DEFAULT (0) FOR [auth_download]
		GO";
	}
	evaluate_statement($sql_query);
}

if (!row_in_shema(AUTH_ACCESS_TABLE, 'auth_download'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") )
	{
		$sql_query = "ALTER TABLE phpbb_auth_access ADD auth_download TINYINT(1) DEFAULT '0' NOT NULL;";
	}
	else if ( $dbms == "postgres" )
	{
		$sql_query = "ALTER TABLE phpbb_auth_access ADD auth_download int2 DEFAULT '0' NOT NULL;";
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE [phpbb_auth_access] WITH NOCHECK ADD
		[auth_download] SMALLINT NOT NULL,
		CONSTRAINT [DF_phpbb_auth_access_auth_download] DEFAULT (0) FOR [auth_download]
		GO";
	}
	evaluate_statement($sql_query);
}

// Begin Update for Beta Tester
if (row_in_shema($attach_desc_table, 'privmsgs_text_id'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") )
	{
		$sql_query = "ALTER TABLE phpbb_attach_desc CHANGE privmsgs_text_id privmsgs_id MEDIUMINT(8) UNSIGNED DEFAULT '0' NOT NULL;";
		evaluate_statement($sql_query);
	}
	else if ( $dbms == "postgres" )
	{
		$sql_query = "ALTER TABLE phpbb_attach_desc RENAME privmsgs_text_id TO privmsgs_id; ALTER TABLE phpbb_attach_desc ALTER privmsgs_id SET DEFAULT '0' NOT NULL;";
		evaluate_statement($sql_query);
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		echo "CANT CHANGE MSSQL-TABLE. PLEASE DO THE FOLLOWING MANUALLY:<br />IN PHPBB_ATTACH_DESC, CHANGE PRIVMSGS_TEXT_ID TO PRIVMSGS_ID.<br />";
	}
}
// End Update for Beta Tester

/*
if (!row_in_shema($attach_desc_table, 'privmsgs_id'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") )
	{
		$sql_query = "ALTER TABLE phpbb_attach_desc ADD privmsgs_id mediumint(8) UNSIGNED NOT NULL DEFAULT '0';";
	}
	else if ( $dbms == "postgres" )
	{
		$sql_query = "ALTER TABLE phpbb_attach_desc ADD privmsgs_id int4 DEFAULT '0' NOT NULL;";
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE [phpbb_attach_desc] WITH NOCHECK ADD
		[privmsgs_id] [int] NOT NULL ,
		CONSTRAINT [DF_phpbb_attach_desc_privmsgs_id] DEFAULT (0) FOR [privmsgs_id]
		GO";
	}
	evaluate_statement($sql_query);
}
*/

//
// Create new Table
//
if ( ($dbms == "mysql") || ($dbms == "mysql4") )
{
	$sql_query = "CREATE TABLE phpbb_attach (
		attach_id MEDIUMINT(8) UNSIGNED DEFAULT '0' NOT NULL, 
		post_id MEDIUMINT(8) UNSIGNED DEFAULT '0' NOT NULL, 
		privmsgs_id MEDIUMINT(8) UNSIGNED DEFAULT '0' NOT NULL
	); ";
}
else if ( $dbms == "postgres" )
{
	$sql_query = "CREATE TABLE phpbb_attach (
		attach_id int4 DEFAULT '0' NOT NULL, 
		post_id int4 DEFAULT '0' NOT NULL, 
		privmsgs_id int4 DEFAULT '0' NOT NULL
	); ";
}
else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
{
	$sql_query = "CREATE TABLE [phpbb_attach] (
		[attach_id] [int] NOT NULL ,
		[post_id] [int] NOT NULL ,
		[privmsgs_id] [int] NOT NULL
	) ON [PRIMARY]
	GO

	ALTER TABLE [phpbb_attach] WITH NOCHECK ADD 
		CONSTRAINT [DF_phpbb_attach_attach_id] DEFAULT (0) FOR [attach_id],
		CONSTRAINT [DF_phpbb_attach_post_id] DEFAULT (0) FOR [post_id],
		CONSTRAINT [DF_phpbb_attach_privmsgs_id] DEFAULT (0) FOR [privmsgs_id],
	GO
	";
}

evaluate_statement($sql_query);

// Now transfer all informations to the new table, if it is needed
if (row_in_shema($attach_desc_table, 'post_id'))
{
	$sql = "SELECT * FROM " . $attach_desc_table;

	$result = query($sql, "Could not query the attachment table");

	$attachments = $db->sql_fetchrowset($result);

	for ($i = 0; $i < count($attachments); $i++)
	{
		if ($attachments[$i]['privmsgs_id'] == '')
		{
			$attachments[$i]['privmsgs_id'] = 0;
		}
		$sql_query = "INSERT INTO phpbb_attach (attach_id, post_id, privmsgs_id) VALUES (" . $attachments[$i]['attach_id'] . ", " . $attachments[$i]['post_id'] . ", " . $attachments[$i]['privmsgs_id'] . "); ";
		evaluate_statement($sql_query);
	}
}

if (row_in_shema($attach_desc_table, 'post_id'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") )
	{
		$sql_query = "ALTER TABLE phpbb_attach_desc DROP post_id;";
		evaluate_statement($sql_query);
	}
	else if ( $dbms == "postgres" )
	{
		echo "<br /><b>PLEASE REMOVE THE FIELD post_id FROM THE TABLE phpbb_attach_desc MANUALLY.</b><br />";
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE phpbb_attach_desc DROP
			CONSTRAINT [DF_phpbb_attach_desc_post_id],
			COLUMN post_id;
		GO	";
		evaluate_statement($sql_query);
	}
}

if (row_in_shema($attach_desc_table, 'privmsgs_id'))
{
	if ( ($dbms == "mysql") || ($dbms == "mysql4") )
	{
		$sql_query = "ALTER TABLE phpbb_attach_desc DROP privmsgs_id;";
		evaluate_statement($sql_query);
	}
	else if ( $dbms == "postgres" )
	{
		echo "<br /><b>PLEASE REMOVE THE FIELD privmsgs_id FROM THE TABLE phpbb_attach_desc MANUALLY.</b><br />";
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$sql_query = "ALTER TABLE phpbb_attach_desc DROP
			CONSTRAINT [DF_phpbb_attach_desc_privmsgs_id],
			COLUMN privmsgs_id;
		GO	";
		evaluate_statement($sql_query);
	}
}

//
// Chmod all Attachments to 777
//
$sql = "SELECT attach_id, attach_filename FROM " . $attach_desc_table;

$result = query($sql, "Couldn't select attachments");

$attach_count = $db->sql_numrows($result);
$attach_data = $db->sql_fetchrowset($result);

for ($i = 0; $i < $attach_count; $i++)
{
	echo "chmod file " . $attach_data[$i]['attach_filename'] . " to 777 ...";
	@chmod($attach_config['upload_dir'] . '/' . $attach_data[$i]['attach_filename'], 0777);
	echo "done<br />";
}

echo "<br />updated table structure to 2.2.1.<br />";

?>