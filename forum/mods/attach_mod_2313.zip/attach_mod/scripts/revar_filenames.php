<?php

define('IN_PHPBB', true);

$phpbb_root_path = './';
include($phpbb_root_path.'extension.inc');
include($phpbb_root_path.'common.'.$phpEx);	
?>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html;">
<meta http-equiv="Content-Style-Type" content="text/css">
<style type="text/css">
<!--

font,th,td,p,body { font-family: "Courier New", courier; font-size: 11pt }

a:link,a:active,a:visited { color : #006699; }
a:hover		{ text-decoration: underline; color : #DD6900;}

hr	{ height: 0px; border: solid #D1D7DC 0px; border-top-width: 1px;}

.maintitle,h1,h2	{font-weight: bold; font-size: 22px; font-family: "Trebuchet MS",Verdana, Arial, Helvetica, sans-serif; text-decoration: none; line-height : 120%; color : #000000;}

.ok {color:green}

/* Import the fancy styles for IE only (NS4.x doesn't use the @import function) */
@import url("templates/subSilver/formIE.css"); 
-->
</style>
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#006699" vlink="#5584AA">

<table width="100%" border="0" cellspacing="0" cellpadding="10" align="center"> 
	<tr>
		<td><table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td><img src="templates/subSilver/images/logo_phpBB.gif" border="0" alt="Forum Home" vspace="1" /></td>
				<td align="center" width="100%" valign="middle"><span class="maintitle">Changing Filenames to a more readable Format</span></td>
			</tr>
		</table></td>
	</tr>
</table>

<br clear="all" />

<?php
function query($sql, $errormsg)
{
	global $db;

	if ( !($result = $db->sql_query($sql)) )
	{
		print "<br><font color=\"red\">\n";
		print "$errormsg<br>";

		$sql_error = $db->sql_error();
		print $sql_error['code'] .": ". $sql_error['message']. "<br>\n";

		print "<pre>$sql</pre>";
		print "</font>\n";

		return FALSE;
	}
	else
	{
		return $result;
	}
}

function only_numbers($filename)
{
	for ($i = 0; $i < strlen($filename); $i++)
	{
		$value = intval($filename[$i]);
		if (empty($value))
		{
			return (FALSE);
		}
	}

	return (TRUE);
}

$dirname = $upload_dir;

$sql = "SELECT * FROM " . ATTACHMENTS_DESC_TABLE;

$result = query($sql, "Could not get Attachments.");

if (intval($attach_config['allow_ftp_upload']))
{
	$conn_id = attach_init_ftp();
}

$attach_ids = array();
$filenames = array();

while ($row = $db->sql_fetchrow($result))
{
	$src_filename = $row['physical_filename'];
	$src_filename_2 = delete_extension($src_filename);
	$src_filename_2 = substr($src_filename_2, 0, strrpos(strtolower(trim($src_filename_2)), '_'));
	if (only_numbers($src_filename_2))
	{

		$dest_filename = stripslashes($row['real_filename']);
		$dest_filename = rawurlencode($dest_filename);
		$dest_filename = preg_replace("/%(\w{2})/", "_", $dest_filename);

		if (physical_filename_already_stored($dest_filename))
		{
			$dest_filename = delete_extension($dest_filename);
			$dest_filename = $dest_filename . '_' . substr(rand(), 0, 3) . '.' . get_extension($row['real_filename']);
		}

		if (!intval($attach_config['allow_ftp_upload']))
		{
			$result_2 = rename($upload_dir . '/' . $src_filename, $upload_dir . '/' . $dest_filename);
			if (!$result_2) print_r('-> File: FROM: ' . $upload_dir . '/' . $src_filename . ' TO: ' . $upload_dir . '/' . $dest_filename);
		
			if (intval($row['thumbnail']) == 1)
			{
				$result_t = rename($upload_dir . '/' . THUMB_DIR . '/t_' . $src_filename, $upload_dir . '/' . THUMB_DIR . '/t_' . $dest_filename);
//				if (!$result_t) print_r('-> File: FROM: ' . $upload_dir . '/' . THUMB_DIR . '/t_' . $src_filename . ' TO: ' . $upload_dir . '/' . THUMB_DIR . '/t_' . $dest_filename);
			}
		}
		else
		{
			$result_2 = ftp_rename($conn_id, $src_filename, $dest_filename);
			if (!$result_2) print_r('-> File: FROM: ' . $src_filename . ' TO: ' . $dest_filename);

			if (intval($row['thumbnail']) == 1)
			{
				$result_t = ftp_rename($conn_id, THUMB_DIR . '/t_' . $src_filename, THUMB_DIR . '/t_' . $dest_filename);
//				if (!$result_t) print_r('-> File: FROM: ' . THUMB_DIR . '/t_' . $src_filename . ' TO: ' . THUMB_DIR . '/t_' . $dest_filename);
			}
		}

		if ($result_2)
		{
			$sql = "UPDATE " . ATTACHMENTS_DESC_TABLE . " SET physical_filename = '" . $dest_filename . "' WHERE attach_id = " . $row['attach_id'];
			query($sql, "Could not update Attachments");
	
			print_r("<br />Renamed <b>" . $src_filename . "</b> to <b>" . $dest_filename . "</b><br />");
		}
	}
}

if (intval($attach_config['allow_ftp_upload']))
{
	ftp_quit($conn_id);
}

?>