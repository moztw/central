<?php

//
// Update File for updating Attachment Mod V2.2.4 to latest version
// $Id: attach_update_224_to_latest.php,v 1.13 2005/05/09 16:23:15 acydburn Exp $
//

error_reporting  (E_ERROR | E_WARNING | E_PARSE); // This will NOT report uninitialized variables
set_magic_quotes_runtime(0); // Disable magic_quotes_runtime

define('IN_PHPBB', true);
define('ATTACH_INSTALL', true);

$phpbb_root_path = './';
include($phpbb_root_path.'extension.inc');
include($phpbb_root_path.'common.'.$phpEx);	
include($phpbb_root_path.'includes/sql_parse.'.$phpEx);

if (!defined('ATTACH_VERSION'))
{
	if (file_exists($phpbb_root_path . 'attach_mod/includes/constants.'.$phpEx))
	{
		include_once($phpbb_root_path . 'attach_mod/includes/constants.'.$phpEx);
	}
}

$attach_version = '';
$attach_version = ATTACH_VERSION;
$attach_version = trim($attach_version);
$version_fields = array();
$version_fields = explode('.', $attach_version);

if ((intval($version_fields[1]) < 2) || (intval($version_fields[0]) != 2))
{
	message_die(GENERAL_MESSAGE, 'Wrong Attachment Version detected.<br />Please update your Attachment Mod (V' . $attach_version . ') to at least Version 2.2.1 before you update to 2.3.13.<br />If the current version was not determined properly, you have to upload the new attachment mod files first.');
}

//
// Check DB Type
//
if ( (!isset($dbms)) || ($dbms == 'oracle') || ($dbms == 'msaccess') )
{
	message_die(GENERAL_MESSAGE, 'This Mod does not support Oracle and MsAccess.');
}

include($phpbb_root_path.'includes/db.'.$phpEx);

$available_dbms = array(
	"mysql" => array(
		"SCHEMA" => "attach_mysql", 
		"DELIM" => ";",
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_remarks"
	), 
	"mysql4" => array(
		"SCHEMA" => "attach_mysql", 
		"DELIM" => ";", 
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_remarks"
	),
	"mssql" => array(
		"SCHEMA" => "attach_mssql", 
		"DELIM" => "GO", 
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_comments"
	),
	"mssql-odbc" =>	array(
		"SCHEMA" => "attach_mssql", 
		"DELIM" => "GO",
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_comments"
	),
	"postgres" => array(
		"LABEL" => "PostgreSQL 7.x",
		"SCHEMA" => "attach_postgres", 
		"DELIM" => ";", 
		"DELIM_BASIC" => ";",
		"COMMENTS" => "remove_comments"
	)
);

$dbms_schema = 'db/schemas/' . $available_dbms[$dbms]['SCHEMA'] . '_schema.sql';
$dbms_basic = 'db/schemas/' . $available_dbms[$dbms]['SCHEMA'] . '_basic.sql';

$remove_remarks = $available_dbms[$dbms]['COMMENTS'];;
$delimiter = $available_dbms[$dbms]['DELIM']; 
$delimiter_basic = $available_dbms[$dbms]['DELIM_BASIC']; 

$old_tables = array(
	$table_prefix . 'attach_config',
	$table_prefix . 'attach_extensions',
	$table_prefix . 'attach_types',
	$table_prefix . 'attach_typeconfig',
	$table_prefix . 'attach_desc',
	$table_prefix . 'attach'
);

$new_tables = array(
	$table_prefix . 'attachments_config',
	$table_prefix . 'forbidden_extensions',
	$table_prefix . 'extension_groups',
	$table_prefix . 'extensions',
	$table_prefix . 'attachments_desc',
	$table_prefix . 'attachments'
);

$userdata = session_pagestart($user_ip, PAGE_INDEX);
init_userprefs($userdata);

//
// BEGIN Functions

//
// A simple query
//
function query($sql, $errormsg)
{
	global $db;

	if ( !($result = $db->sql_query($sql)) )
	{
		print "<br><font color=\"red\">\n";
		print "$errormsg<br>";

		$sql_error = $db->sql_error();
		print $sql_error['code'] .": ". $sql_error['message']. "<br>\n";

		print "<pre>$sql</pre>";
		print "</font>\n";

		return FALSE;
	}
	else
	{
		return $result;
	}
}

//
// Insert a value into the Attachment Configuration Table
//
// Syntax: old_row_name, new_row_name, TRUE if it's a new row, default value if it's a new row
function insert_into_config($old_name, $new_name, $is_new, $default = -1)
{
	global $db, $old_tables, $new_tables, $dbms;

	$backup_config_table = $old_tables[0] . '_bck';
	$new_config_table = $new_tables[0];

	if ( ($is_new) && ($default != -1) )
	{
		$sql = "SELECT config_name FROM " . $new_config_table . " WHERE config_name='" . $new_name . "'";

		$result = $db->sql_query($sql);

		if ($db->sql_numrows($result) != 0)
		{
			return;
		}

		// Write new config variable
		if ( ($dbms == 'mysql') || ($dbms == 'mysql4') || ($dbms == 'postgres') )
		{
			$sql = "INSERT INTO " . $new_config_table . " (config_name, config_value) VALUES ('" . $new_name . "', '" . $default . "');";
		}
		else if ( ($dbms == 'mssql') || ($dbms == 'mssql-odbc') )
		{
			$sql = "INSERT INTO " . $new_config_table . " (config_name, config_value) VALUES ('" . $new_name . "', '" . $default . "');";
			$sql .= "GO;";
		}
		
		if ($new_name == 'ftp_pass')
		{
			echo "Running :: INSERT Ftp Password into config Table";
			evaluate_statement($sql, TRUE);
		}
		else
		{
			evaluate_statement($sql);
		}

		return;
	}
	
	// Get old Data
	$sql = "SELECT config_value FROM " . $backup_config_table . " WHERE config_name='" . $old_name . "'";

	$result = $db->sql_query($sql);

	if ($db->sql_numrows($result) == 0)
	{
		echo "Could not find the value for config_name " . $new_name;
		return;
	}

	$row = $db->sql_fetchrow($result);
	$value = $row['config_value'];

	if ( ($dbms == 'mysql') || ($dbms == 'mysql4') || ($dbms == 'postgres') )
	{
		$sql = "INSERT INTO " . $new_config_table . " (config_name, config_value) VALUES ('" . $new_name . "', '" . $value . "');";
	}
	else if ( ($dbms == 'mssql') || ($dbms == 'mssql-odbc') )
	{
		$sql = "INSERT INTO $new_config_table (config_name, config_value) VALUES ('$new_name', '$value');";
		$sql .= "GO;";
	}
		
	if ($new_name == 'ftp_pass')
	{
		echo "Running :: INSERT Ftp Password into config Table";
		evaluate_statement($sql, TRUE);
	}
	else
	{
		evaluate_statement($sql);
	}
}

//
// Check if a given row is present in table $table
//
function row_in_shema($table, $key)
{
	global $db, $table_prefix;

	$sql = "SELECT " . $key . " FROM " . $table;

	$result = $db->sql_query($sql);

	if ($result)
	{
		return (TRUE);
	}
	else
	{
		return (FALSE);
	}
}

//
// Run a complete SQL-Statement, this can be a array
//
function evaluate_statement($sql_query, $hide = FALSE, $replace = FALSE)
{
	global $table_prefix, $remove_remarks, $delimiter, $db;
	
	$errored = FALSE;
	if ($replace)
	{
		$sql_query = preg_replace('/phpbb_/', $table_prefix, $sql_query);
	}

	$sql_query = $remove_remarks($sql_query);
	$sql_query = split_sql_file($sql_query, $delimiter);

	$sql_count = count($sql_query);

	for($i = 0; $i < $sql_count; $i++)
	{
		if (!$hide)
		{
			echo "Running :: " . $sql_query[$i];
		}
		flush();

		if ( !($result = $db->sql_query($sql_query[$i])) )
		{
			$errored = true;
			$error = $db->sql_error();
			if (!$hide)
			{
				echo " -> <b>FAILED</b> ---> <u>" . $error['message'] . "</u><br /><br />\n\n";
			}
		}
		else
		{
			if (!$hide)
			{
				echo " -> <b><span class=\"ok\">COMPLETED</span></b><br /><br />\n\n";
			}
		}
	}

	if ($errored)
	{
		return (FALSE);
	}
	else
	{
		return $result;
	}
}

function rename_table($source_tablename, $dest_tablename)
{
	global $dbms;

	if ( ($dbms == 'mysql') || ($dbms == 'mysql4') )
	{
		$sql_query = 'ALTER TABLE ' . $source_tablename . ' RENAME ' . $dest_tablename . ';';
	}
	else if ( ($dbms == 'mssql') || ($dbms == 'mssql-odbc') )
	{
		$sql_query = "sp_rename '" . $source_tablename . "', '" . $dest_tablename . "';";
		$sql_query .= "GO;";
	}
	else if ($dbms == 'postgres')
	{
		$sql_query = 'ALTER TABLE ' . $source_tablename . ' RENAME TO ' . $dest_tablename . ';';
	}

	if (!evaluate_statement($sql_query))
	{
		die("<br />Could not rename Table, therefore exiting the Update Process. Please write down the errors shown above.<br />");
	}
}

function backup_tables_exist()
{
	global $db, $old_tables;
	
	for ($i = 0; $i < count($old_tables); $i++)
	{
		$sql = "SELECT * FROM " . $old_tables[$i] . '_bck';

		$result = $db->sql_query($sql);

		if (!$result)
		{
			return (FALSE);
		}
	}

	return (TRUE);
}

function table_exist($table)
{
	global $db, $table_prefix;
	
	$sql = "SELECT * FROM " . $table;

	$result = $db->sql_query($sql);

	if (!$result)
	{
		return (FALSE);
	}
	else
	{
		return (TRUE);
	}
}

function delete_table($table)
{
	global $db, $dbms;

	if (table_exist($table))
	{
		if ( ($dbms == 'mysql') || ($dbms == 'mysql4') || ($dbms == 'postgres') )
		{
			$sql_query = 'DROP TABLE ' . $table . ';';
		}
		else if ( ($dbms == 'mssql') || ($dbms == 'mssql-odbc') )
		{
			$sql_query = 'DROP TABLE ' . $table . ';';
			$sql_query .= 'GO;';
		}

		if (!evaluate_statement($sql_query))
		{
			die("<br />Could not delete Table, therefore exiting the Update Process. Please write down the errors shown above.<br />");
		}
	}
}

function insert_data_ext_groups($data_row)
{
	global $new_tables, $dbms;

	$table = $new_tables[2];
	
	if ( ($dbms == 'mysql') || ($dbms == 'mysql4') || ($dbms == 'postgres') )
	{
		$sql_query = "INSERT INTO " . $table . " (group_id, group_name, cat_id, allow_group, download_mode, upload_icon, max_filesize, forum_permissions) VALUES (" . $data_row['group_id'] . ", '" . trim($data_row['group_name']) . "', " . $data_row['cat_id'] . ", " . $data_row['allow_group'] . ", " . $data_row['download_mode'] . ", '" . trim($data_row['upload_icon']) . "', " . $data_row['max_filesize'] . ", '');";
	}
	else if ( ($dbms == 'mssql') || ($dbms == 'mssql-odbc') )
	{
		$sql_query = "SET IDENTITY_INSERT " . $table . " ON; GO";
		$sql_query .= "INSERT INTO " . $table . " (group_id, group_name, cat_id, allow_group, download_mode, upload_icon, max_filesize, forum_permissions) VALUES (" . $data_row['group_id'] . ", '" . trim($data_row['group_name']) . "', " . $data_row['cat_id'] . ", " . $data_row['allow_group'] . ", " . $data_row['download_mode'] . ", '" . trim($data_row['upload_icon']) . "', " . $data_row['max_filesize'] . ",'');";
		$sql_query .= "GO";
		$sql_query .= "SET IDENTITY_INSERT " . $table . " OFF; GO";
	}

	evaluate_statement($sql_query);
}

function insert_data_extensions($data_row)
{
	global $new_tables, $dbms;

	$table = $new_tables[3];

	if ( ($dbms == 'mysql') || ($dbms == 'mysql4') || ($dbms == 'postgres') )
	{
		$sql_query = "INSERT INTO " . $table . " (group_id, extension, comment) VALUES (" . $data_row['group_id'] . ", '" . $data_row['extension'] . "', '" . $data_row['comment'] . "');";
	}
	else if ( ($dbms == 'mssql') || ($dbms == 'mssql-odbc') )
	{
		$sql_query = "INSERT INTO " . $table . " (group_id, extension, comment) VALUES (" . $data_row['group_id'] . ", '" . $data_row['extension'] . "', '" . $data_row['comment'] . "');";
		$sql_query .= "GO;";	
	}

	evaluate_statement($sql_query);
}

function insert_attachments_desc($data_row)
{
	global $new_tables, $dbms;

	$table = $new_tables[4];

	$comment = trim($data_row['comment']);
	$comment = str_replace("'", "''", $comment);
		
	$real_filename = str_replace("'", "''", $data_row['real_filename']);

	if ( ($dbms == 'mysql') || ($dbms == 'mysql4') || ($dbms == 'postgres') )
	{
		
		$sql_query = "INSERT INTO " . $table . " (attach_id, physical_filename, real_filename, download_count, comment, extension, mimetype, filesize, filetime, thumbnail) VALUES (" . $data_row['attach_id'] . ", '" . $data_row['physical_filename'] . "', '" . $real_filename . "', " . $data_row['download_count'] . ", '" . $comment . "', '" . $data_row['extension'] . "', '" . $data_row['mimetype'] . "', " . $data_row['filesize'] . ", " . $data_row['filetime'] . ", " . $data_row['thumbnail'] . ");";
	}
	else if ( ($dbms == 'mssql') || ($dbms == 'mssql-odbc') )
	{
		$sql_query = "SET IDENTITY_INSERT " . $table . " ON; GO";
		$sql_query .= "INSERT INTO " . $table . " (attach_id, physical_filename, real_filename, download_count, comment, extension, mimetype, filesize, filetime, thumbnail) VALUES (" . $data_row['attach_id'] . ", '" . $data_row['physical_filename'] . "', '" . $real_filename . "', " . $data_row['download_count'] . ", '" . $comment . "', '" . $data_row['extension'] . "', '" . $data_row['mimetype'] . "', " . $data_row['filesize'] . ", " . $data_row['filetime'] . ", " . $data_row['thumbnail'] . ");";
		$sql_query .= "GO";
		$sql_query .= "SET IDENTITY_INSERT " . $table . " OFF; GO";
	}

	evaluate_statement($sql_query);
}

function insert_attachment($data_row)
{
	global $new_tables, $old_tables, $dbms, $db;

	$table = $new_tables[5];

	// Get User id, if it's a post
	if ($data_row['post_id'] != 0)
	{
		$data_row['user_id_2'] = 0;

		$sql = "SELECT u.user_id, p.topic_id
		FROM " . $old_tables[5] . "_bck a, " . USERS_TABLE . " u, " . POSTS_TABLE . " p
		WHERE (a.post_id = p.post_id) AND (u.user_id = p.poster_id) AND (a.post_id = " . $data_row['post_id'] . ")";
		
		if ( !($result = $db->sql_query($sql)) )
		{
			echo "<br /><b>Error getting user_id from post: " . $data_row['post_id'] . "</b>";
			return;
		}

		if ($db->sql_numrows($result) == 0)
		{
			return (FALSE);
		}

		$row = $db->sql_fetchrow($result);
		$data_row['user_id_1'] = $row['user_id'];
		$topic_id = $row['topic_id'];
		
		if ( ($dbms == 'mysql') || ($dbms == 'mysql4') || ($dbms == 'postgres') )
		{
			$sql = "UPDATE " . POSTS_TABLE . " SET post_attachment = 1 WHERE post_id = " . $data_row['post_id'] . ";";
		}
		else if ( ($dbms == 'mssql') || ($dbms == 'mssql-odbc') )
		{
			$sql = "UPDATE " . POSTS_TABLE . " SET post_attachment = 1 WHERE post_id = " . $data_row['post_id'] . ";";
			$sql .= "GO;";
		}
		
		if (!evaluate_statement($sql))
		{
			echo "<br /><b>Error updating post: " . $data_row['post_id'] . "</b><br />";
			return;
		}

		if ( ($dbms == 'mysql') || ($dbms == 'mysql4') || ($dbms == 'postgres') )
		{
			$sql = "UPDATE " . TOPICS_TABLE . " SET topic_attachment = 1 WHERE topic_id = " . $topic_id . ";";
		}
		else if ( ($dbms == 'mssql') || ($dbms == 'mssql-odbc') )
		{
			$sql = "UPDATE " . TOPICS_TABLE . " SET topic_attachment = 1 WHERE topic_id = " . $topic_id . ";";
			$sql .= "GO;";
		}

		if (!evaluate_statement($sql))
		{
			echo "<br /><b>Error updating topic: " . $data_row['topic_id'] . "</b><br />";
			return;
		}
	}
	else if ($data_row['privmsgs_id'] != 0)
	{
		$sql = "SELECT privmsgs_from_userid, privmsgs_to_userid 
		FROM " . PRIVMSGS_TABLE . "
		WHERE (privmsgs_id = " . $data_row['privmsgs_id'] . ")";

		if ( !($result = $db->sql_query($sql)) )
		{
			echo "<br /><b>Error getting user_id's from pm: " . $data_row['privmsgs_id'] . "</b>";
			return;
		}

		if ($db->sql_numrows($result) == 0)
		{
			return (FALSE);
		}

		$row = $db->sql_fetchrow($result);
		$data_row['user_id_1'] = $row['privmsgs_from_userid'];
		$data_row['user_id_2'] = $row['privmsgs_to_userid'];

		if ( ($dbms == 'mysql') || ($dbms == 'mysql4') || ($dbms == 'postgres') )
		{
			$sql = "UPDATE " . PRIVMSGS_TABLE . " SET privmsgs_attachment = 1 WHERE privmsgs_id = " . $data_row['privmsgs_id'] . ";";
		}
		else if ( ($dbms == 'mssql') || ($dbms == 'mssql-odbc') )
		{
			$sql = "UPDATE " . PRIVMSGS_TABLE . " SET privmsgs_attachment = 1 WHERE privmsgs_id = " . $data_row['privmsgs_id'] . ";";
			$sql .= "GO;";
		}
		
		if (!evaluate_statement($sql))
		{
			echo "<br /><b>Error updating pm: " . $data_row['privmsgs_id'] . "</b>";
			return;
		}
	}
	else
	{
		$data_row['user_id_1'] = 0;
		$data_row['user_id_2'] = 0;
	}

	if ( ($dbms == 'mysql') || ($dbms == 'mysql4') || ($dbms == 'postgres') )
	{
		$sql_query = "INSERT INTO " . $table . " (attach_id, post_id, privmsgs_id, user_id_1, user_id_2) VALUES (" . $data_row['attach_id'] . ", " . $data_row['post_id'] . ", " . $data_row['privmsgs_id'] . ", " . $data_row['user_id_1'] . ", " . $data_row['user_id_2'] . ");";
	}
	else if ( ($dbms == 'mssql') || ($dbms == 'mssql-odbc') )
	{
		$sql_query = "INSERT INTO " . $table . " (attach_id, post_id, privmsgs_id, user_id_1, user_id_2) VALUES (" . $data_row['attach_id'] . ", " . $data_row['post_id'] . ", " . $data_row['privmsgs_id'] . ", " . $data_row['user_id_1'] . ", " . $data_row['user_id_2'] . ");";
		$sql_query .= "GO;";
	}

	evaluate_statement($sql_query);
}

function fill_new_table_data($dbms)
{
	
	$data = '';

	if ( ($dbms == 'mysql') || ($dbms == 'mysql4') )
	{
		$data = '
CREATE TABLE phpbb_attachments_config (
  config_name varchar(255) NOT NULL,
  config_value varchar(255) NOT NULL,
  PRIMARY KEY (config_name)
);

CREATE TABLE phpbb_forbidden_extensions (
  ext_id mediumint(8) UNSIGNED NOT NULL auto_increment, 
  extension varchar(100) NOT NULL, 
  PRIMARY KEY (ext_id)
);

CREATE TABLE phpbb_extension_groups (
  group_id mediumint(8) NOT NULL auto_increment,
  group_name char(20) NOT NULL,
  cat_id tinyint(2) DEFAULT \'0\' NOT NULL, 
  allow_group tinyint(1) DEFAULT \'0\' NOT NULL,
  download_mode tinyint(1) UNSIGNED DEFAULT \'1\' NOT NULL,
  upload_icon varchar(100) DEFAULT \'\',
  max_filesize int(20) DEFAULT \'0\' NOT NULL,
  forum_permissions varchar(255) default \'\' NOT NULL,
  PRIMARY KEY group_id (group_id)
);

CREATE TABLE phpbb_extensions (
  ext_id mediumint(8) UNSIGNED NOT NULL auto_increment,
  group_id mediumint(8) UNSIGNED DEFAULT \'0\' NOT NULL,
  extension varchar(100) NOT NULL,
  comment varchar(100),
  PRIMARY KEY ext_id (ext_id)
);

CREATE TABLE phpbb_attachments_desc (
  attach_id mediumint(8) UNSIGNED NOT NULL auto_increment,
  physical_filename varchar(255) NOT NULL,
  real_filename varchar(255) NOT NULL,
  download_count mediumint(8) UNSIGNED DEFAULT \'0\' NOT NULL,
  comment varchar(255),
  extension varchar(100),
  mimetype varchar(100),
  filesize int(20) NOT NULL,
  filetime int(11) DEFAULT \'0\' NOT NULL,
  thumbnail tinyint(1) DEFAULT \'0\' NOT NULL,
  PRIMARY KEY (attach_id),
  KEY filetime (filetime),
  KEY physical_filename (physical_filename(10)),
  KEY filesize (filesize)
);

CREATE TABLE phpbb_attachments (
  attach_id mediumint(8) UNSIGNED DEFAULT \'0\' NOT NULL, 
  post_id mediumint(8) UNSIGNED DEFAULT \'0\' NOT NULL, 
  privmsgs_id mediumint(8) UNSIGNED DEFAULT \'0\' NOT NULL,
  user_id_1 mediumint(8) NOT NULL,
  user_id_2 mediumint(8) NOT NULL,
  KEY attach_id_post_id (attach_id, post_id),
  KEY attach_id_privmsgs_id (attach_id, privmsgs_id)
); 

CREATE TABLE phpbb_quota_limits (
  quota_limit_id mediumint(8) unsigned NOT NULL auto_increment,
  quota_desc varchar(20) NOT NULL default \'\',
  quota_limit bigint(20) unsigned NOT NULL default \'0\',
  PRIMARY KEY  (quota_limit_id)
);

CREATE TABLE phpbb_attach_quota (
  user_id mediumint(8) unsigned NOT NULL default \'0\',
  group_id mediumint(8) unsigned NOT NULL default \'0\',
  quota_type smallint(2) NOT NULL default \'0\',
  quota_limit_id mediumint(8) unsigned NOT NULL default \'0\',
  KEY quota_type (quota_type)
);

INSERT INTO phpbb_quota_limits (quota_limit_id, quota_desc, quota_limit) VALUES (1, \'Low\', 262144);
INSERT INTO phpbb_quota_limits (quota_limit_id, quota_desc, quota_limit) VALUES (2, \'Medium\', 2097152);
INSERT INTO phpbb_quota_limits (quota_limit_id, quota_desc, quota_limit) VALUES (3, \'High\', 5242880);

';
	}
	else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
	{
		$data = '
BEGIN TRANSACTION
GO

CREATE TABLE [phpbb_attachments_config] (
	[config_name] [varchar] (100) NOT NULL ,
	[config_value] [varchar] (100) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [phpbb_forbidden_extensions] (
	[ext_id] [int] IDENTITY (1, 1) NOT NULL ,
	[extension] [char] (100) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [phpbb_extension_groups] (
	[group_id] [int] IDENTITY (1, 1) NOT NULL ,
	[group_name] [char] (20) NOT NULL ,
	[cat_id] [tinyint] NOT NULL ,
	[allow_group] [tinyint] NOT NULL ,
	[download_mode] [tinyint] NOT NULL ,
	[upload_icon] [varchar] (100) NOT NULL ,
	[max_filesize] [int] NOT NULL ,
	[forum_permissions] [varchar] (255) NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [phpbb_extensions] (
	[ext_id] [int] IDENTITY (1, 1) NOT NULL ,
	[group_id] [int] NOT NULL ,
	[extension] [varchar] (100) NOT NULL ,
	[comment] [varchar] (100) NOT NULL 
) ON [PRIMARY] 
GO

CREATE TABLE [phpbb_attachments_desc] (
	[attach_id] [int] IDENTITY (1, 1) NOT NULL ,
	[physical_filename] [varchar] (100) NOT NULL ,
	[real_filename] [varchar] (100) NOT NULL ,
	[download_count] [int] NOT NULL ,
	[comment] [varchar] (100) NULL ,
	[extension] [varchar] (100) NULL ,
	[mimetype] [varchar] (50) NULL ,
	[filesize] [int] NOT NULL ,
	[filetime] [int] NOT NULL ,
	[thumbnail] [tinyint] NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [phpbb_attachments] (
	[attach_id] [int] NOT NULL ,
	[post_id] [int] NOT NULL ,
	[privmsgs_id] [int] NOT NULL ,
	[user_id_1] [int] NOT NULL,
	[user_id_2] [int] NOT NULL
)
GO

CREATE TABLE [phpbb_quota_limits] (
  [quota_limit_id] [int] IDENTITY (1, 1) NOT NULL ,
  [quota_desc] [varchar] (20) NOT NULL,
  [quota_limit] [bigint] NOT NULL
) ON [PRIMARY];

CREATE TABLE [phpbb_attach_quota] (
  [user_id] [int] NOT NULL,
  [group_id] [int] NOT NULL,
  [quota_type] [tinyint] NOT NULL,
  [quota_limit_id] [int] NOT NULL
);

ALTER TABLE [phpbb_attachments_config] WITH NOCHECK ADD 
	CONSTRAINT [PK_phpbb_attachments_config] PRIMARY KEY CLUSTERED 
	(
		[config_name]
	)  ON [PRIMARY] 
GO

ALTER TABLE [phpbb_forbidden_extensions] WITH NOCHECK ADD 
	CONSTRAINT [PK_phpbb_forbidden_extensions] PRIMARY KEY CLUSTERED 
	(
		[ext_id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [phpbb_extension_groups] WITH NOCHECK ADD 
	CONSTRAINT [PK_phpbb_extension_groups] PRIMARY KEY  CLUSTERED 
	(
		[group_id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [phpbb_extension_groups] WITH NOCHECK ADD 
	CONSTRAINT [DF_phpbb_extension_groups_cat_id] DEFAULT (0) FOR [cat_id],
	CONSTRAINT [DF_phpbb_extension_groups_allow_group] DEFAULT (0) FOR [allow_group],
	CONSTRAINT [DF_phpbb_extension_groups_download_mode] DEFAULT (1) FOR [download_mode],
	CONSTRAINT [DF_phpbb_extension_groups_max_filesize] DEFAULT (0) FOR [max_filesize]
GO

ALTER TABLE [phpbb_extensions] WITH NOCHECK ADD 
	CONSTRAINT [PK_phpbb_extensions] PRIMARY KEY  CLUSTERED 
	(
		[ext_id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [phpbb_extensions] WITH NOCHECK ADD 
	CONSTRAINT [DF_phpbb_extensions_group_id] DEFAULT (0) FOR [group_id]
GO

ALTER TABLE [phpbb_attachments_desc] WITH NOCHECK ADD 
	CONSTRAINT [PK_phpbb_attachments_desc] PRIMARY KEY  CLUSTERED 
	(
		[attach_id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [phpbb_attachments_desc] WITH NOCHECK ADD 
	CONSTRAINT [DF_phpbb_attachments_desc_download_count] DEFAULT (0) FOR [download_count],
	CONSTRAINT [DF_phpbb_attachments_desc_thumbnail] DEFAULT (0) FOR [thumbnail],
	CONSTRAINT [DF_phpbb_attachments_desc_filetime] DEFAULT (0) FOR [filetime]
GO

ALTER TABLE [phpbb_attachments] WITH NOCHECK ADD 
	CONSTRAINT [DF_phpbb_attachments_attach_id] DEFAULT (0) FOR [attach_id],
	CONSTRAINT [DF_phpbb_attachments_post_id] DEFAULT (0) FOR [post_id],
	CONSTRAINT [DF_phpbb_attachments_privmsgs_id] DEFAULT (0) FOR [privmsgs_id]
GO

ALTER TABLE [phpbb_quota_limits] WITH NOCHECK ADD 
	CONSTRAINT [PK_phpbb_quota_limits] PRIMARY KEY  CLUSTERED 
	(
		[quota_limit_id]
	)  ON [PRIMARY] 
GO

ALTER TABLE [phpbb_quota_limits] WITH NOCHECK ADD 
	CONSTRAINT [DF_phpbb_quota_limits_quota_limit] DEFAULT (0) FOR [quota_limit]
GO

ALTER TABLE [phpbb_attach_quota] WITH NOCHECK ADD 
	CONSTRAINT [DF_phpbb_attach_quota_user_id] DEFAULT (0) FOR [user_id],
	CONSTRAINT [DF_phpbb_attach_quota_group_id] DEFAULT (0) FOR [group_id],
	CONSTRAINT [DF_phpbb_attach_quota_quota_type] DEFAULT (0) FOR [quota_type],
	CONSTRAINT [DF_phpbb_attach_quota_quota_limit_id] DEFAULT (0) FOR [quota_limit_id]
GO

COMMIT
GO

BEGIN TRANSACTION
GO

SET IDENTITY_INSERT phpbb_quota_limits ON;

INSERT INTO phpbb_quota_limits (quota_limit_id, quota_desc, quota_limit) VALUES (1, \'Low\', 262144);
INSERT INTO phpbb_quota_limits (quota_limit_id, quota_desc, quota_limit) VALUES (2, \'Medium\', 2097152);
INSERT INTO phpbb_quota_limits (quota_limit_id, quota_desc, quota_limit) VALUES (3, \'High\', 5242880);

SET IDENTITY_INSERT phpbb_quota_limits OFF;

COMMIT
GO

	';
	}
	else if ($dbms == 'postgres')
	{
		$data = '
CREATE SEQUENCE phpbb_extensions_id_seq start 1 increment 1 maxvalue 2147483647 minvalue 1 cache 1;
CREATE SEQUENCE phpbb_forbidden_extensions_id_seq start 1 increment 1 maxvalue 2147483647 minvalue 1 cache 1;
CREATE SEQUENCE phpbb_extension_groups_id_seq start 1 increment 1 maxvalue 2147483647 minvalue 1 cache 1;
CREATE SEQUENCE phpbb_attachments_desc_id_seq start 1 increment 1 maxvalue 2147483647 minvalue 1 cache 1;
CREATE SEQUENCE phpbb_quota_limits_quota_limit_id_seq start 1 increment 1 maxvalue 2147483647 minvalue 1 cache 1;

CREATE TABLE phpbb_attachments_config (
   config_name varchar(255) NOT NULL,
   config_value varchar(255) NOT NULL,
   CONSTRAINT phpbb_attachments_config_pkey PRIMARY KEY (config_name)
);

CREATE TABLE phpbb_forbidden_extensions (
  ext_id int2 DEFAULT nextval(\'phpbb_forbidden_extensions_id_seq\'::text) NOT NULL,
  extension varchar(100) DEFAULT \'\' NOT NULL, 
  CONSTRAINT phpbb_forbidden_extensions_pkey PRIMARY KEY (ext_id)
);

CREATE TABLE phpbb_extension_groups (
  group_id int4 DEFAULT nextval(\'phpbb_extension_groups_id_seq\'::text) NOT NULL,
  group_name varchar(20) NOT NULL,
  cat_id int2 DEFAULT 0 NOT NULL,
  allow_group int2 DEFAULT 0 NOT NULL,
  download_mode int2 DEFAULT 1 NOT NULL,
  upload_icon varchar(100) DEFAULT \'\',
  max_filesize int4 DEFAULT 0 NOT NULL,
  forum_permissions varchar(255) NOT NULL,
  CONSTRAINT phpbb_extension_groups_pkey PRIMARY KEY (group_id)
);

CREATE TABLE phpbb_extensions (
  ext_id int2 DEFAULT nextval(\'phpbb_extensions_id_seq\'::text) NOT NULL,
  group_id int4 DEFAULT 0 NOT NULL,
  extension varchar(100) NOT NULL,
  comment varchar(100),
  CONSTRAINT phpbb_extensions_pkey PRIMARY KEY (ext_id)
);

CREATE TABLE phpbb_attachments_desc (
  attach_id int4 DEFAULT nextval(\'phpbb_attachments_desc_id_seq\'::text) NOT NULL,
  physical_filename varchar(255) NOT NULL,
  real_filename varchar(255) NOT NULL,
  download_count int4 DEFAULT 0 NOT NULL,
  comment varchar(255) DEFAULT \'\',
  extension varchar(100),
  mimetype varchar(100),
  filesize int4 NOT NULL,
  filetime int4 DEFAULT 0 NOT NULL,
  thumbnail int2 DEFAULT 0 NOT NULL,
  CONSTRAINT phpbb_attachments_desc_pkey PRIMARY KEY (attach_id)
);

CREATE TABLE phpbb_attachments (
  attach_id int4 DEFAULT 0 NOT NULL, 
  post_id int4 DEFAULT 0 NOT NULL, 
  privmsgs_id int4 DEFAULT 0 NOT NULL,
  user_id_1 int4 NOT NULL,
  user_id_2 int4 NOT NULL
); 
CREATE INDEX attach_id_post_id_phpbb_attachments_index ON phpbb_attachments (attach_id, post_id);
CREATE INDEX attach_id_privmsgs_id_phpbb_attachments_index ON phpbb_attachments (attach_id, privmsgs_id);

CREATE TABLE phpbb_quota_limits (
  quota_limit_id int4 DEFAULT nextval(\'phpbb_quota_limits_quota_limit_id_seq\'::text) NOT NULL,
  quota_desc varchar(20) DEFAULT \'\' NOT NULL,
  quota_limit int8 DEFAULT 0 NOT NULL,
  CONSTRAINT phpbb_quota_limits_pkey PRIMARY KEY (quota_limit_id)
);

CREATE TABLE phpbb_attach_quota (
  user_id int4 DEFAULT 0 NOT NULL,
  group_id int4 DEFAULT 0 NOT NULL,
  quota_type int2 DEFAULT 0 NOT NULL,
  quota_limit_id int4 DEFAULT 0 NOT NULL
);
CREATE INDEX quota_type_phpbb_attach_quota_index ON phpbb_attach_quota (quota_type);

INSERT INTO phpbb_quota_limits (quota_desc, quota_limit) VALUES (\'Low\', 262144);
INSERT INTO phpbb_quota_limits (quota_desc, quota_limit) VALUES (\'Medium\', 2097152);
INSERT INTO phpbb_quota_limits (quota_desc, quota_limit) VALUES (\'High\', 5242880);

';
	}

	return $data;
}

// END Functions
//

if( isset($HTTP_POST_VARS['step']) || isset($HTTP_GET_VARS['step']) )
{
	$step = ( isset($HTTP_POST_VARS['step']) ) ? $HTTP_POST_VARS['step'] : $HTTP_GET_VARS['step'];
}
else
{
	$step = '';
}

if ($step != 'migrate_mimes')
{
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html;">
<meta http-equiv="Content-Style-Type" content="text/css">
<style type="text/css">
<!--

font,th,td,p,body { font-family: "Courier New", courier; font-size: 11pt }

a:link,a:active,a:visited { color : #006699; }
a:hover		{ text-decoration: underline; color : #DD6900;}

hr	{ height: 0px; border: solid #D1D7DC 0px; border-top-width: 1px;}

.maintitle,h1,h2	{font-weight: bold; font-size: 22px; font-family: "Trebuchet MS",Verdana, Arial, Helvetica, sans-serif; text-decoration: none; line-height : 120%; color : #000000;}

.ok {color:green}

/* Import the fancy styles for IE only (NS4.x doesn't use the @import function) */
@import url("templates/subSilver/formIE.css"); 
-->
</style>
</head>
<body bgcolor="#FFFFFF" text="#000000" link="#006699" vlink="#5584AA">

<table width="100%" border="0" cellspacing="0" cellpadding="10" align="center"> 
	<tr>
		<td><table width="100%" border="0" cellspacing="0" cellpadding="0">
			<tr>
				<td><img src="templates/subSilver/images/logo_phpBB.gif" border="0" alt="Forum Home" vspace="1" /></td>
				<td align="center" width="100%" valign="middle"><span class="maintitle">Updating to latest Attachment Mod Version</span></td>
			</tr>
		</table></td>
	</tr>
</table>

<br clear="all" />

<?php
}

$template->set_filenames(array(
	'body' => '../../attach_update_224_to_latest.tpl')
);

//
// See if we have nice backups...
//
if ($step == '')
{
	if ( (!backup_tables_exist()) && (!table_exist($new_tables[5])) )
	{
		echo "<br /><h2>Backup Attachment Mod Tables...</h2><br /><br />";
		for ($i = 0; $i < count($old_tables); $i++)
		{
			rename_table($old_tables[$i], $old_tables[$i] . '_bck');
		}
		echo "<br /><br /><b>Backup Attachment Mod Tables finished.</b><br /><br />";
	}
	else
	{
		//
		// Backup Tables are there, therefore the Backup process started sometimes
		// Present the User his choices
		//
		if (backup_tables_exist())
		{
?>
<br />
The Updater has detected that the Update Process is finished or was started earlier.<br />
At any time, you can run the Updater. You will be directed to this Selection Screen.<br />
Now you have two Options to choose:<br />
<br />
<a href="attach_update_224_to_latest.php?step=delete">Delete all Backup Tables</a> (NOTE: YOU CANNOT UNDO THE UPDATE PROCESS IF YOU CHOOSE THIS)<br />
<a href="attach_update_224_to_latest.php?step=undo">Undo all Changes made by the Updater</a> (NOTE: PLEASE MAKE SURE YOU HAVE NOT EDITED THE FILES FOR THE NEW VERSION, ALL OLD FILES AND CHANGES HAVE TO BE INTACT)<br />
<br />
<?php
			exit();
		}
		else
		{
?>
<br />
The Updater has detected that the Update Process was started earlier and that you have chosen to use the new Attachment Mod Version.<br />
You have decided to delete the Backuped Tables, therefore the Update Process can't be reverted.<br />
<?php
			exit();		
		}
	}

	echo "<center>Please look for any errors displayed and write them down. (You can save the Page if you want. ;) ).";
	echo "<br />When you want to continue the Update, please click this Link:<br />";
	echo "<a href=\"attach_update_224_to_latest.php?step=create_new_tables\">Create New Tables</a><br />";
	echo "Or execute the Updater directly with: <b>attach_update_224_to_latest.php?step=create_new_tables</b><br /></center>";
	exit();
}

if ($step == 'create_new_tables')
{
	echo "<br /><h2>Install new Database Schema...</h2><br /><br />";

	$sql_query = fill_new_table_data($dbms);

	evaluate_statement($sql_query, FALSE, TRUE);

	//
	// ALTER Table Statements
	//
	if (!row_in_shema(POSTS_TABLE, 'post_attachment'))
	{
		if ( ($dbms == "mysql") || ($dbms == "mysql4") )
		{
			$sql_query = "ALTER TABLE phpbb_posts ADD post_attachment TINYINT(1) DEFAULT '0' NOT NULL;";
		}
		else if ( $dbms == "postgres" )
		{
			$sql_query = '
ALTER TABLE phpbb_posts ADD post_attachment int2;
UPDATE phpbb_posts SET post_attachment = 0;
ALTER TABLE phpbb_posts ALTER COLUMN post_attachment SET DEFAULT 0;
ALTER TABLE phpbb_posts ADD CONSTRAINT post_attachment_notnull CHECK (post_attachment NOTNULL);
';
		}
		else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
		{
			$sql_query = "ALTER TABLE [phpbb_posts] WITH NOCHECK ADD 
	[post_attachment] [int] NOT NULL,
	CONSTRAINT [DF_phpbb_posts_post_attachment] DEFAULT (0) FOR [post_attachment]
GO	";
		}

		evaluate_statement($sql_query, FALSE, TRUE);
	}

	if (!row_in_shema(TOPICS_TABLE, 'topic_attachment'))
	{	
		if ( ($dbms == "mysql") || ($dbms == "mysql4") )
		{
			$sql_query = "ALTER TABLE phpbb_topics ADD topic_attachment TINYINT(1) DEFAULT '0' NOT NULL;";
		}
		else if ( $dbms == "postgres" )
		{
			$sql_query = '
ALTER TABLE phpbb_topics ADD topic_attachment int2;
UPDATE phpbb_topics SET topic_attachment = 0;
ALTER TABLE phpbb_topics ALTER COLUMN topic_attachment SET DEFAULT 0;
ALTER TABLE phpbb_topics ADD CONSTRAINT topic_attachment_notnull CHECK (topic_attachment NOTNULL);
';
		}
		else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
		{
			$sql_query = "ALTER TABLE [phpbb_topics] WITH NOCHECK ADD 
	[topic_attachment] [int] NOT NULL,
	CONSTRAINT [DF_phpbb_topics_topic_attachment] DEFAULT (0) FOR [topic_attachment]
GO  ";
		}
		evaluate_statement($sql_query, FALSE, TRUE);
	}

	if (!row_in_shema(PRIVMSGS_TABLE, 'privmsgs_attachment'))
	{
		if ( ($dbms == "mysql") || ($dbms == "mysql4") )
		{
			$sql_query = "ALTER TABLE phpbb_privmsgs ADD privmsgs_attachment TINYINT(1) DEFAULT '0' NOT NULL;";
		}
		else if ( $dbms == "postgres" )
		{
			$sql_query = '
ALTER TABLE phpbb_privmsgs ADD privmsgs_attachment int2;
UPDATE phpbb_privmsgs SET privmsgs_attachment = 0;
ALTER TABLE phpbb_privmsgs ALTER COLUMN privmsgs_attachment SET DEFAULT 0;
ALTER TABLE phpbb_privmsgs ADD CONSTRAINT privmsgs_attachment_notnull CHECK (privmsgs_attachment NOTNULL);
';
		}
		else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
		{
			$sql_query = "ALTER TABLE [phpbb_privmsgs] WITH NOCHECK ADD 
	[privmsgs_attachment] [int] NOT NULL,
	CONSTRAINT [DF_phpbb_privmsgs_privmsgs_attachment] DEFAULT (0) FOR [privmsgs_attachment]
GO  ";
		}
		evaluate_statement($sql_query, FALSE, TRUE);
	}

	echo "<br /><br /><b>New Database Schema installed.</b><br /><br />";
	echo "<center>Please look for any errors displayed and write them down. (You can save the Page if you want. ;) ).";
	echo "<br />When you want to continue the Update, please click this Link:<br />";
	echo "<a href=\"attach_update_224_to_latest.php?step=fill_new_config\">Fill New Config</a><br />";
	echo "Or execute the Updater directly with: <b>attach_update_224_to_latest.php?step=fill_new_config</b><br /></center>";
	exit();
}	

if ($step == 'fill_new_config')
{
	//
	// Build up the config table
	//
	
	echo "<br /><h2>Migrate Configuration Table...</h2><br /><br />";
	// Syntax: old_row_name, new_row_name, TRUE if it's a new row, default value if it's a new row
	insert_into_config('upload_dir', 'upload_dir', FALSE);
	insert_into_config('upload_img', 'upload_img', FALSE);
	insert_into_config('topic_icon', 'topic_icon', FALSE);
	insert_into_config('', 'display_order', TRUE, '0');
	insert_into_config('max_filesize', 'max_filesize', FALSE);
	insert_into_config('attachment_quota', 'attachment_quota', FALSE);
	insert_into_config('max_filesize_pm', 'max_filesize_pm', FALSE);
	insert_into_config('max_attachments', 'max_attachments', FALSE);
	insert_into_config('max_attachments_pm', 'max_attachments_pm', FALSE);
	insert_into_config('disable_mod', 'disable_mod', FALSE);
	insert_into_config('allow_pm_attach', 'allow_pm_attach', FALSE);
	insert_into_config('', 'show_apcp', TRUE, '1');
	insert_into_config('', 'attachment_topic_review', TRUE, '0');
	insert_into_config('allow_ftp_upload', 'allow_ftp_upload', FALSE);
	insert_into_config('', 'ftp_server', TRUE, '');
	insert_into_config('ftp_path', 'ftp_path', FALSE);
	insert_into_config('download_path', 'download_path', FALSE);
	insert_into_config('ftp_user', 'ftp_user', FALSE);
	insert_into_config('ftp_pass', 'ftp_pass', FALSE);
	insert_into_config('', 'ftp_pasv_mode', TRUE, '1');
	insert_into_config('', 'attach_version', TRUE, '2.3.13');
	insert_into_config('', 'default_upload_quota', TRUE, '0');
	insert_into_config('', 'default_pm_quota', TRUE, '0');

	// Determine if we have a special Category Images defined. If so, the value has to be 1, otherwise 0
	$inlined = '1';

	$sql = "SELECT t.allow_type
	FROM phpbb_attach_typeconfig_bck m, phpbb_attach_types_bck t 
	WHERE (t.allow_type = '1') AND (m.type_id = t.type_id) AND (t.type_id = " . IMAGE_CAT . ");";

	$sql = preg_replace('/phpbb_/', $table_prefix, $sql);

	$result = query($sql, 'Couldn\'t determine default value for image inline view');
	
	if ($result)
	{
		if ($db->sql_numrows($result) != 0)
		{
			$row = $db->sql_fetchrow($result);
			if (intval($row['allow_type']) == 0)
			{
				$inlined = '0';
			}
		}
		else
		{
			$inlined = '0';
		}
	}
	insert_into_config('', 'img_display_inlined', TRUE, $inlined);

	insert_into_config('', 'img_max_width', TRUE, '0');
	insert_into_config('', 'img_max_height', TRUE, '0');
	insert_into_config('', 'img_link_width', TRUE, '0');
	insert_into_config('', 'img_link_height', TRUE, '0');
	insert_into_config('', 'img_create_thumbnail', TRUE, '0');
	insert_into_config('', 'img_min_thumb_filesize', TRUE, '12000');
	insert_into_config('', 'img_imagick', TRUE, '');
	insert_into_config('', 'wma_autoplay', TRUE, '0');
	insert_into_config('', 'flash_autoplay', TRUE, '0');

	echo "<br /><br /><b>Migration of Configuration Table finished...</b><br /><br />";
	echo "<center>Please look for any errors displayed and write them down. (You can save the Page if you want. ;) ).";
	echo "<br />When you want to continue the Update, please click this Link:<br />";
	echo "<a href=\"attach_update_224_to_latest.php?step=migrate_groups\">Migrate Mime Groups</a><br />";
	echo "Or execute the Updater directly with: <b>attach_update_224_to_latest.php?step=migrate_groups</b><br /></center>";
	exit();
}

if ($step == 'migrate_groups')
{
	echo "<br /><h2>Migrate Mime Groups...</h2><br /><br />";

	//
	// Build up the Attachment Types (Extension Groups now)
	//
	$sql = "SELECT * FROM " . $old_tables[2] . "_bck";
	
	if(!$result = $db->sql_query($sql))
	{
		$sql_error = $db->sql_error();

		$debug_text = '';

		if ( $sql_error['message'] != '' )
		{
			$debug_text .= '<br /><br />SQL Error : ' . $sql_error['code'] . ' ' . $sql_error['message'];
		}

		die("<b>Could not query tables: " . $sql . "<br />Please contact the Acyd Burn at www.opentools.de" . $debug_text . "</b>");
	}

	$rows = $db->sql_fetchrowset($result);
	$num_rows = $db->sql_numrows($result);

	for ($i = 0; $i < $num_rows; $i++)
	{
		// Build the Data Row
		$data_row['group_id'] = $rows[$i]['type_id'];
		$data_row['group_name'] = $rows[$i]['type_name'];
		$data_row['cat_id'] = $rows[$i]['category'];
		$data_row['allow_group'] = $rows[$i]['allow_type'];
		$data_row['download_mode'] = $rows[$i]['download_mode'];
		$data_row['upload_icon'] = $rows[$i]['upload_image'];
		$data_row['max_filesize'] = $rows[$i]['max_filesize'];
	
		// Now INSERT
		insert_data_ext_groups($data_row);
	}

	echo "<br /><br ><b>Migrating of Mime Groups finished.</b><br /><br />";
	echo "<center>Please look for any errors displayed and write them down. (You can save the Page if you want. ;) ).";
	echo "<br />If you are finished with this, please continue the Update with this Link:<br />";
	echo "<a href=\"attach_update_224_to_latest.php?step=migrate_mimes\">Migrate Mime Types</a><br />";
	echo "Or execute the Updater directly with: <b>attach_update_224_to_latest.php?step=migrate_mimes</b><br /></center>";
	echo "In the next Update Step you will prompted to enter default Extensions, but at the most time Extensions";
	echo "are predefined, a default value will be displayed.<br />";
	exit();
}

if ($step == 'migrate_mimes')
{
	include($phpbb_root_path. 'includes/page_header.'.$phpEx);

	$template->assign_block_vars('switch_migrate_mimes', array());

	//
	// Get the used Mime Types and their Group Status
	//
	$sql = "SELECT * FROM " . $old_tables[3] . "_bck";
	
	if(!$result = $db->sql_query($sql))
	{
		$sql_error = $db->sql_error();

		$debug_text = '';

		if ( $sql_error['message'] != '' )
		{
			$debug_text .= '<br /><br />SQL Error : ' . $sql_error['code'] . ' ' . $sql_error['message'];
		}

		die("<b>Could not query tables: " . $sql . "<br />Please contact Acyd Burn at www.opentools.de" . $debug_text . "</b>");

	}

	$rows = $db->sql_fetchrowset($result);
	$num_rows = $db->sql_numrows($result);

	$template->assign_vars(array(
		'L_EXPLAIN' => 'Please enter a corresponding Extension for the displayed MimeType on each field. If a field is empty, it will be NOT migrated to the Attachment Mod, you will then loose the MimeType/Extension and have to re-enter it.',
		'S_ACTION' => append_sid('attach_update_224_to_latest.'.$phpEx.'?step=migrate_mimes_submit'))
	);

	for ($i = 0; $i < $num_rows; $i++)
	{
		// Split up all space-seperated comments (extensions)
		$extensions = array();
		$extensions = explode(' ', $rows[$i]['explain_mimetype']);

		for ($i2 = 0; $i2 < count($extensions); $i2++)
		{
			
			$template->assign_block_vars('switch_migrate_mimes.extension_row', array(
				'GROUP_ID' => $rows[$i]['type_id'],
				'MIMETYPE' => $rows[$i]['type_string'],
				'EXTENSION' => trim($extensions[$i2]))
			);
		}
	}

	$template->pparse('body');
	
	include($phpbb_root_path . 'includes/page_tail.'.$phpEx);
	exit();
}

$submit = $HTTP_POST_VARS['submit'];

if ( ($step == 'migrate_mimes_submit') && ($submit) )
{
	echo "<br /><h2>Migrate Mime Types...</h2><br /><br />";

	$group_id_list = ( isset($HTTP_POST_VARS['group_id_list']) ) ? $HTTP_POST_VARS['group_id_list'] : array();
	$extension_list = ( isset($HTTP_POST_VARS['extension_list']) ) ? $HTTP_POST_VARS['extension_list'] : array();
	$comment_list = ( isset($HTTP_POST_VARS['comment_list']) ) ? $HTTP_POST_VARS['comment_list'] : array();

	$new_group_id_list = array();
	$new_extension_list = array();
	$new_comment_list = array();

	//
	// Yeah... let's see which extension is proudful to be added
	//
	for ($i = 0; $i < count($group_id_list); $i++)
	{
		$extension = trim(strip_tags($extension_list[$i]));
		$extension = strtolower($extension);

		if ($extension != '')
		{
			if (!in_array($extension, $new_extension_list) )
			{
				$new_group_id_list[] = intval($group_id_list[$i]);
				$new_extension_list[] = $extension;
				$new_comment_list[] = trim(strip_tags($comment_list[$i]));
			}
		}
	}
	
	for ($i = 0; $i < count($new_extension_list); $i++)
	{
		// Build the Data Row
		$data_row['group_id'] = $new_group_id_list[$i];
		$data_row['extension'] = $new_extension_list[$i];
		$data_row['comment'] = $new_comment_list[$i];
	
		// Now INSERT
		insert_data_extensions($data_row);
	}

	echo "<br /><br /><b>Migrating Mime Types finished.<br /><br /></b>";
	echo "<center>Please look for any errors displayed and write them down. (You can save the Page if you want. ;) ).";
	echo "<br />When you want to continue the Update, please click this Link:<br />";
	echo "<a href=\"attach_update_224_to_latest.php?step=forbidden_extensions\">Migrate Forbidden Extensions</a><br />";
	echo "Or execute the Updater directly with: <b>attach_update_224_to_latest.php?step=forbidden_extensions</b><br /></center>";
	exit();
}

if ($step == 'forbidden_extensions')
{
	echo "<br /><h2>Migrate Forbidden Extensions...</h2><br /><br />";
	
	$sql = "SELECT * FROM " . $old_tables[1] . "_bck";
	
	if(!$result = $db->sql_query($sql))
	{
		$sql_error = $db->sql_error();

		$debug_text = '';

		if ( $sql_error['message'] != '' )
		{
			$debug_text .= '<br /><br />SQL Error : ' . $sql_error['code'] . ' ' . $sql_error['message'];
		}

		die("<b>Could not query tables: " . $sql . "<br />Please contact the Acyd Burn at www.opentools.de" . $debug_text . "</b>");
	}

	$rows = $db->sql_fetchrowset($result);
	$num_rows = $db->sql_numrows($result);

	for ($i = 0; $i < $num_rows; $i++)
	{
		if ( ($dbms == 'mysql') || ($dbms == 'mysql4') || ($dbms == 'postgres') )
		{
			$sql_query = "INSERT INTO " . $new_tables[1] . " (ext_id, extension) VALUES (" . ($i+1) . ", '" . trim($rows[$i]['extension']) . "');";
		}
		else if ( ($dbms == 'mssql') || ($dbms == 'mssql-odbc') )
		{
			$sql_query = "INSERT INTO " . $new_tables[1] . " (extension) VALUES ('" . trim($rows[$i]['extension']) . "');";
			$sql_query .= "GO;";
		}
		evaluate_statement($sql_query);
	}

	echo "<br /><br /><b>Migrating Forbidden Extensions finished.<br /><br /></b>";
	echo "<center>Please look for any errors displayed and write them down. (You can save the Page if you want. ;) ).";
	echo "<br />When you want to continue the Update, please click this Link:<br />";
	echo "<a href=\"attach_update_224_to_latest.php?step=migrate_attachments_desc\">Migrate Attachments (Phase 1/2)</a><br />";
	echo "Or execute the Updater directly with: <b>attach_update_224_to_latest.php?step=migrate_attachments_desc</b><br /></center>";
	exit();
}

if ($step == 'migrate_attachments_desc')
{
	echo "<br /><h2>Migrate Attachment Descriptions...</h2><br /><br />";

	if ( (!table_exist($old_tables[4] . '_bck')) || (!table_exist($old_tables[5] . '_bck')) )
	{
		die("<br /><b>Needed Attachment Mod Backup Tables do not exist</b>");
	}

	//
	// Ok, first of all the Attachment Descriptions
	//
	$sql = "SELECT * FROM " . $old_tables[4] . "_bck";
	
	if(!$result = $db->sql_query($sql))
	{
		$sql_error = $db->sql_error();

		$debug_text = '';

		if ( $sql_error['message'] != '' )
		{
			$debug_text .= '<br /><br />SQL Error : ' . $sql_error['code'] . ' ' . $sql_error['message'];
		}

		die("<b>Could not query table: " . $sql . "<br />Please contact Acyd Burn at www.opentools.de" . $debug_text . "</b>");
	}

//	$rows = $db->sql_fetchrowset($result);
//	$num_rows = $db->sql_numrows($result);

	while ($row = $db->sql_fetchrow($result))
	{
		$data_row['attach_id'] = $row['attach_id'];
		$data_row['physical_filename'] = $row['attach_filename'];
		$data_row['real_filename'] = $row['filename'];
		$data_row['download_count'] = $row['download_count'];
		$data_row['comment'] = $row['comment'];

		$extension = strrchr(strtolower($data_row['real_filename']), '.');
		$extension[0] = ' ';
		$extension = strtolower(trim($extension));

		$data_row['extension'] = $extension;
		$data_row['mimetype'] = $row['mimetype'];
		$data_row['filesize'] = $row['filesize'];
		$data_row['filetime'] = $row['filetime'];
		$data_row['thumbnail'] = 0;

		insert_attachments_desc($data_row);
	}

	echo "<br /><br /><b>Migrating Attachment Descriptions finished.<br /><br /></b>";
	echo "<center>Please look for any errors displayed and write them down. (You can save the Page if you want. ;) ).";
	echo "<br />When you want to continue the Update, please click this Link:<br />";
	echo "<a href=\"attach_update_224_to_latest.php?step=migrate_attachments\">Migrate Attachments (Phase 2/2)</a><br />";
	echo "Or execute the Updater directly with: <b>attach_update_224_to_latest.php?step=migrate_attachments</b><br /></center>";
	exit();
}

if ($step == 'migrate_attachments')
{
	echo "<br /><h2>Migrate Attachments...</h2><br /><br />";

	if ( (!table_exist($old_tables[4] . '_bck')) || (!table_exist($old_tables[5] . '_bck')) )
	{
		die("<br /><b>Needed Attachment Mod Backup Tables do not exist</b>");
	}
	
	//
	// Now the Attachments itself: update posts, forums, topics, pm's, user_id's
	//
	$sql = "SELECT * FROM " . $old_tables[5] . "_bck";
	
	if(!$result = $db->sql_query($sql))
	{
		$sql_error = $db->sql_error();

		$debug_text = '';

		if ( $sql_error['message'] != '' )
		{
			$debug_text .= '<br /><br />SQL Error : ' . $sql_error['code'] . ' ' . $sql_error['message'];
		}

		die("<b>Could not query table: " . $sql . "<br />Please contact Acyd Burn at www.opentools.de" . $debug_text . "</b>");
	}

//	$rows = $db->sql_fetchrowset($result);
//	$num_rows = $db->sql_numrows($result);

	while ($row = $db->sql_fetchrow($result))
	{
		$data_row['attach_id'] = $row['attach_id'];
		$data_row['post_id'] = $row['post_id'];
		$data_row['privmsgs_id'] = $row['privmsgs_id'];
		insert_attachment($data_row);
	}
	
	echo "<br /><br /><b>Migrating Attachments finished (it might be good to run the attach_update_23x_to_latest.php script too).<br /><br /></b>";
	echo "<br /><center><a href=\"attach_update_224_to_latest." . $phpEx . "\">Finished...</a></center><br />";
	exit();
}

if ($step == 'delete')
{
	for ($i = 0; $i < count($old_tables); $i++)
	{
		delete_table($old_tables[$i] . '_bck');
		if ( ($dbms == 'postgres') && ($i != 0) && ($i != 5) )
		{
			$sql_query = 'DROP SEQUENCE ' . $old_tables[$i] . '_id_seq;';
			evaluate_statement($sql_query);
		}
	}

	echo "<br />Tables Deleted.<br />";
	exit();
}

if ($step == 'undo')
{
	if (!backup_tables_exist())
	{
		die("<b>Cannot Undo the changes. The Backup Database Tables do not exist anymore.</b>");
	}

	for ($i = 0; $i < count($new_tables); $i++)
	{
		delete_table($new_tables[$i]);
		if ( ($dbms == 'postgres') && ($i != 0) && ($i != 5) )
		{
			$sql_query = 'DROP SEQUENCE ' . $new_tables[$i] . '_id_seq;';
			evaluate_statement($sql_query);
		}
	}

	for ($i = 0; $i < count($old_tables); $i++)
	{
		rename_table($old_tables[$i] . '_bck', $old_tables[$i]);
	}

	//
	// Delete the Attachment Indicators
	//
	if (row_in_shema(POSTS_TABLE, 'post_attachment'))
	{
		if ( ($dbms == "mysql") || ($dbms == "mysql4") )
		{
			$sql_query = "ALTER TABLE " . POSTS_TABLE . " DROP post_attachment;";
			evaluate_statement($sql_query);
		}
		else if ( $dbms == "postgres" )
		{
			echo "Please drop the Field post_attachment in your phpbb_posts table manually";
		}
		else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
		{
			$sql_query = "ALTER TABLE phpbb_posts DROP
				CONSTRAINT [DF_phpbb_posts_post_attachment],
				COLUMN post_attachment;
			GO	";
			evaluate_statement($sql_query, FALSE, TRUE);
		}

	}

	if (row_in_shema(TOPICS_TABLE, 'topic_attachment'))
	{	
		if ( ($dbms == "mysql") || ($dbms == "mysql4") )
		{
			$sql_query = "ALTER TABLE " . TOPICS_TABLE . " DROP topic_attachment;";
			evaluate_statement($sql_query);
		}
		else if ( $dbms == "postgres" )
		{
			echo "Please drop the Field topic_attachment in your phpbb_topics table manually";
		}
		else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
		{
			$sql_query = "ALTER TABLE phpbb_topics DROP
				CONSTRAINT [DF_phpbb_topics_topic_attachment],
				COLUMN topic_attachment;
			GO	";
			evaluate_statement($sql_query, FALSE, TRUE);
		}
	}

	if (row_in_shema(PRIVMSGS_TABLE, 'privmsgs_attachment'))
	{
		if ( ($dbms == "mysql") || ($dbms == "mysql4") )
		{
			$sql_query = "ALTER TABLE " . PRIVMSGS_TABLE . " DROP privmsgs_attachment;";
			evaluate_statement($sql_query);
		}
		else if ( $dbms == "postgres" )
		{
			echo "Please drop the Field privmsgs_attachment in your phpbb_privmsgs table manually";
		}
		else if ( ($dbms == "mssql") || ($dbms == "mssql-odbc") )
		{
			$sql_query = "ALTER TABLE phpbb_privmsgs DROP
				CONSTRAINT [DF_phpbb_privmsgs_privmsgs_attachment],
				COLUMN privmsgs_attachment;
			GO	";
			evaluate_statement($sql_query, FALSE, TRUE);
		}
	}

	echo "<br /><h2>The old Attachment Mod Tables (Version 2.2.4) were restored.</h2><br />";
	exit();
}

?>