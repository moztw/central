Installation Instructions:

This is Version 2.3.13 of the Attachment Mod.

The File Attachment Mod only supports phpBB 2.0.6 to 2.0.15.
The File Attachment Mod does NOT support *Nuke Portals or phpBB2 Ports.

Please read the Attachment Mod User Guide (docs/user_guide.html) to get familiar with the Attachment Mod.

For Installation Instructions, please read docs/install.txt.
If you want to update, you do not need to read docs/install.txt, instead read docs/update_23x_to_latest.txt (if you are
updating from at least version 2.3.0 of the attachment mod).

If you want to update from versions prior to 2.3.0, you have to re-apply the changes
to your phpBB Installation (manually or by using the pre-modified files). The scripts for
changing/updating the database schema can be found within the scripts directory (please read the readme.txt
file within this folder).

Please use the support forum at http://www.opentools.de if you have problems.
The latest version of the Attachment Mod can be found at http://www.opentools.de too.

Acyd Burn